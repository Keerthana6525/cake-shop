document.addEventListener('DOMContentLoaded', function() {
    const Images = document.querySelectorAll('.gcard');

    Images.forEach(function(image) {
            image.addEventListener('mouseenter', function() {
            image.style.transform = 'scale(1.2)';
        });

            image.addEventListener('mouseleave', function() {
            image.style.transform = 'scale(1)';
      });
    });
});




const textElement = document.getElementById('textEffect');

textElement.addEventListener('mouseover', function() {
  textElement.style.color = 'blue';
  textElement.style.textShadow = '4px 4px 6px rgba(0, 0, 0, 0.7)';
});

textElement.addEventListener('mouseout', function() {
  textElement.style.color = 'yellow';
  textElement.style.textShadow = '2px 2px 4px rgba(0, 0,0,0.5)';
});



